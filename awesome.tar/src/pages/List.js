import React, { Component } from "react";
import { connect } from "react-redux";


import { View, Text, TouchableOpacity, Button, Alert } from 'react-native'

const mapStateToProps = state => {
  return { articles: state.articles };
};

genRandomIcon = (index) => (index%2==0) ? "🍌":"🍑"

const ConnectedList = ({ articles }) => (
  <View style={{ backgroundColor: 'red', margin: 20 }}>
    <Text>
      how many acticles {articles.length}
    </Text>
    {articles.map((el, index) => (
      <TouchableOpacity key={index}>
        <Text>
          article {el.title? el.title: genRandomIcon(index)}
        </Text>
      </TouchableOpacity>
    ))}
  </View>
);

const List = connect(mapStateToProps)(ConnectedList);

export default List;