import { Provider } from "react-redux";
import React from "react";
import {Text, View,TouchableOpacity,Button,Alert,StyleSheet} from 'react-native'
import Form from './Form'
import List from './List'
import store from '../store/Article'



export default class DumbRegister extends React.Component{

    constructor(props){
        super(props)
    }

    render() {
        return (
            <Provider store={store}>
                <View style={{marginTop:30}}>
                    <Text>This is merely dumb action</Text>
                    <List/>
                    <Form/>
                </View>
            </Provider>
        )
    }

    
}

const styles = StyleSheet.create(
    {
        button: {
            backgroundColor:'red'
        },
        text: {
            backgroundColor:'red',
            fontSize:16
        }
    }
        
)