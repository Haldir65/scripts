import React, { useState, useContext, useReducer } from 'react'
import { TouchableOpacity, Text, SafeAreaView, View } from 'react-native'

// use Context , share data between children(of the same parent)
const AppContext = React.createContext({});

const myReducer = (state, action) => {
    switch (action.type) {
        case ('countUp'):
            return {
                ...state,
                count: state.count + 1
            }
        default:
            return state
    }
}


const Navbar = () => {
    const { userName } = useContext(AppContext);
    return (
        <Text>
            navBar saw data as {userName}
        </Text>
    )
}


const button = () => {
    const [buttonText, setButtonText] = useState("Click me,   please");
    const [clicked, setClicked] = useState(false)
    const handleClick = (e) => {
        setButtonText(clicked ? "click me" : 'clicked')
        setClicked(!clicked)
    }

    const [state, dispatch] = useReducer(myReducer, { count: 0 });

    return (<SafeAreaView>
        <View style={{ justifyContent: "center", margin: 30 }}>
            <Text style={{ textAlign: 'center', color: '#00ced1' }}>
                useState Sample
           </Text>
            <TouchableOpacity onPress={handleClick}>
                <Text style={{ textAlign: 'center', backgroundColor: '#7fff00' }}>
                    {buttonText} {clicked ? "🍉" : "🍇"}
                </Text>
            </TouchableOpacity>
        </View>

        <View>
            <View style={{ justifyContent: 'center', flexDirection: 'row', justifyContent: 'space-around' }}>
                <Text style={{
                    textAlign: 'center', color: '#6495ed', flex: 1,
                    backgroundColor: "red"
                }}>
                    useContext Sample1
            </Text>
                <Text style={{ textAlign: 'center', color: '#6495ed', flex: 3, backgroundColor: "yellow" }}>
                    useContext Sample2
            </Text>
            </View>
            <AppContext.Provider value={{
                userName: 'barney'
            }}>
                <View>
                    <Navbar />
                    <Navbar />
                </View>
            </AppContext.Provider>
        </View>

        <View>
            <View style={{ flexDirection: 'row', backgroundColor: 'pink', justifyContent: 'center' }}>
                <Text style={{ textAlign: 'center', color: '#1e90ff', backgroundColor: 'fuchsia' }}>how to useReducer</Text>
            </View>
            <TouchableOpacity
                onPress={() => {
                    // alert('pressed!')
                    dispatch({ type: 'countUp' })
                }}
            >
                <Text>
                    press me
                </Text>
                <Text>
                    count from useReducer {state.count}
                </Text>

            </TouchableOpacity>
        </View>




    </SafeAreaView>)
}

export default button