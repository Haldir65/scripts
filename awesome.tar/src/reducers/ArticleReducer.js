import {ADD_ARTICLE, DELETE_ARTICLE} from '../constants/action-types' 

const initialState = {
    articles: []
  };

  function rootReducer(state = initialState, action) {
    switch(action.type){
        case ADD_ARTICLE:
            console.log('current state ', state.articles)
            return Object.assign({}, state, {
                articles: state.articles.concat(action.payload)
              });
        default:
            return initialState    
    }
  }

  export default rootReducer