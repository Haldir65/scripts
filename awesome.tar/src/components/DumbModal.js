import React, { Component} from 'react';
import {
    Modal, Text, TouchableHighlight, View,
    Alert, SafeAreaView, Picker, StyleSheet,
    StatusBar,
    Platform,
} from 'react-native';

const MyStatusBar = ({backgroundColor, ...props}) => (
    <View style={[styles.statusBar, { backgroundColor }]}>
      <StatusBar translucent backgroundColor={backgroundColor} {...props} />
    </View>
  );

class ModalExample extends Component {
    state = {
        modalVisible: false,
    };

    setModalVisible(visible) {
        this.setState({ modalVisible: visible });
    }

    render() {
        return (
            <View style={{ marginTop: 22 }}>
                 <MyStatusBar backgroundColor="red" barStyle="dark-content" />
                <Modal
                    animationType="slide"
                    transparent={false}
                    visible={this.state.modalVisible}
                    onRequestClose={() => {
                        Alert.alert('Modal has been closed.');
                    }}>
                    <View style={{ marginTop: 72, alignItems: 'center' }}>
                        <View style={{ backgroundColor: 'yellow' }}>
                            <Text>Hello World!</Text>

                            <TouchableHighlight
                                onPress={() => {
                                    this.setModalVisible(!this.state.modalVisible);
                                }}>
                                <Text>Hide Modal</Text>
                            </TouchableHighlight>
                        </View>
                    </View>
                </Modal>


                    <TouchableHighlight
                        onPress={() => {
                            this.setModalVisible(true);
                        }}
                        style={{ backgroundColor: 'red', justifyContent: 'center' }}
                    >
                        <Text style={{ textAlign: "center" }}>Show Modal</Text>
                    </TouchableHighlight>

                    <Picker
                        selectedValue={this.state.language}
                        style={{
                            height: 50,
                            width: 100,
                            backgroundColor: 'yellow',
                            position: 'relative'
                        }}
                        onValueChange={(itemValue, itemIndex) =>
                            this.setState({ language: itemValue })
                        }
                        itemStyle={{ backgroundColor: "pink", color: "green", fontSize: 17 }}
                    >
                        <Picker.Item label="Java" value="java" color='blue' />
                        <Picker.Item label="JavaScript" value="js" />
                    </Picker>

            </View>
        );
    }
  
}

const STATUSBAR_HEIGHT = Platform.OS === 'ios' ? 20 : StatusBar.currentHeight;
const APPBAR_HEIGHT = Platform.OS === 'ios' ? 44 : 56;

const styles = StyleSheet.create({
    safeArea: {
     flex: 1,
     backgroundColor: 'red'
    },
    container: {
        flex: 1,
      },
      statusBar: {
        height: STATUSBAR_HEIGHT,
      },
      appBar: {
        backgroundColor:'#79B45D',
        height: APPBAR_HEIGHT,
      },
      content: {
        flex: 1,
        backgroundColor: '#33373B',
      },
   })

export default ModalExample