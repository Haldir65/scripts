import React, { Component }from 'react';
import {
    View,
    Text,
    Image,
    StyleSheet,
    Dimensions
  } from 'react-native';

export default class Avatar extends Component {


    onLayout = (e) => {
      this.setState({
        width: e.nativeEvent.layout.width,
        height: e.nativeEvent.layout.height,
        x: e.nativeEvent.layout.x,
        y: e.nativeEvent.layout.y
      })
      console.log("onlayout === ")
    }
  
    render() {

      return (
      <View onLayout={this.onLayout} 
      style={{backgroundColor:"yellow",flexDirection:"row"}}>
          <View style={{flexDirection:"column",alignItems:"center"}}>
            <Image source={{ uri: 'https://www.baidu.com/img/bd_logo1.png' }}  
                style={styles.avatar}/>   
            <Text>
                120元起
            </Text>     
          </View>
          <View style={{flexDirection:"column",justifyContent:"space-around"}}>
            <Text style={{alignSelf:"flex-start",backgroundColor:"red"}}>First line of text, First line of text</Text>
            <Text style={{alignSelf:"flex-start",backgroundColor:"purple",color:"white"}}>second line of text</Text>
            <Text style={{alignSelf:"flex-start",backgroundColor:"blue"}}>My Picture</Text>
          </View>
      </View>
      )
    }

    
  }

  const windowWidth = Dimensions.get('window').width
  const windowHeight = Dimensions.get('window').height

  const styles = StyleSheet.create({
    avatar: {
        margin: 2,
        width: windowWidth/8,
        height: windowHeight/10
    },
    txt: {
        alignSelf: "flex-end"
    }
})