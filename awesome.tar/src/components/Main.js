import React, {Component} from 'react'
import {SectionList, Text, View, StyleSheet, SafeAreaView, Platform,StatusBar, TextInput,Keyboard,ScrollView} from 'react-native'
import CitySectionList from './CitySectionList'

const ITEM_HEIGHT = 50; //item的高度
const HEADER_HEIGHT = 24;  //分组头部的高度
const SEPARATOR_HEIGHT = 0;  //分割线的高度

const returnTrue = () => true


export  default  class Main extends Component {

    async getCityInfos() {
        let data = await require('../assets/city.json');
        let jsonData = data.data
        //每组的开头在列表中的位置
        let totalSize = 0;
        //SectionList的数据源
        let cityInfos = [];
        //分组头的数据源
        let citySection = [];
        //分组头在列表中的位置
        let citySectionSize = [];
        for (let i = 0; i < jsonData.length; i++) {
            citySectionSize[i] = totalSize;
            //给右侧的滚动条进行使用的
            citySection[i] = jsonData[i].title;
            let section = {}
            section.key = jsonData[i].title;
            section.data = jsonData[i].city;
            for (let j = 0; j < section.data.length; j++) {
                section.data[j].key = j
            }
            cityInfos[i] = section;
            //每一项的header的index
            totalSize += section.data.length + 1
        }
        this.setState({data: cityInfos, sections: citySection, sectionSize: citySectionSize})
    }


    constructor(props) {
        super(props);
        this.state = {
            data: [],
            sections: [],
            sectionSize: []
        }
        this.getCityInfos()
    }

    componentDidMount(){
        console.log('==componentDidMount===')
    }

    render() {

        if (this.state.data.length > 0) {
            return (
                <View style={{paddingTop: Platform.OS === 'android' ? 0 : 20}}>
                      <StatusBar backgroundColor="blue" 
                    networkActivityIndicatorVisible='true'
                    hidden={false} barStyle='dark-content' />
                    <SafeAreaView style={flex = '1'}>
                    <View >
                        <View style={{
                            padding:10,
                            backgroundColor:'gray',
                            justifyContent:'space-around',
                            alignItems:'center',
                            flexDirection:'column',
                            alignContent:'flex-start'
                        }}>
                            <Text style={{
                                color: 'white',
                                backgroundColor: 'red',
                            }}>
                                This is the search View
                            </Text>
                            <TextInput style={{
                                alignSelf:'stretch',
                                margin: 5,
                                backgroundColor:'white',
                                borderTopRightRadius: 15,
                                borderTopLeftRadius: 15,
                                borderBottomLeftRadius:15,
                                borderBottomRightRadius:15,
                                overflow: 'hidden',
                                paddingStart: 20,
                                paddingTop: 10,
                                paddingBottom:10,
                                fontSize:16
                            }}  autoFocus={true} returnKeyType='go' 
                            autoCapitalize='none'
                            clearButtonMode='always'
                            placeholder ='请输入你想要查找的城市'
                                ref='input'>
                            </TextInput>
                        </View>
                        <SectionList
                            ref='list'
                            enableEmptySections
                            renderItem={this._renderItem}
                            renderSectionHeader={this._renderSectionHeader}
                            sections={this.state.data}
                            getItemLayout={this._getItemLayout}
                            onScrollToIndexFailed={this._onScrollToIndexFailed}
                            onScroll={(e) => {
                                console.log("onScroll", e)
                            }}
                            />
                        <CitySectionList
                            sections={ this.state.sections}
                            onSectionSelect={this._onSectionselect}
                            onSectionUp ={() => {
                                console.log("onSectionup======")
                                Keyboard.dismiss()
                            }
                            }
                            />
                    </View>
                    </SafeAreaView>
                </View>
            )
        } else {
            return <View/>
        }
    }

    //这边返回的是A,0这样的数据
    _onSectionselect = (section, index) => {
        console.log(index) // 9
        console.log(section) // K
        console.log(this.state.sectionSize)// [0 ,52 ,143 ..]
        //跳转到某一项
        let tindex = -1;
        if(index==0){
            tindex = 0
        }
        this.refs.list.scrollToLocation({animated: false, 
            sectionIndex: index, // 一级
            itemIndex: -1, // 二级
            viewPosition: 0,
            viewOffset : 0
        })
        // this.refs.list.scrollToLocation({animated: true, 
        //     sectionIndex: 2,
        //     itemIndex: 10,
        // })
    }

    _getItemLayout(data, index) {
        let [length, separator, header] = [ITEM_HEIGHT, SEPARATOR_HEIGHT, HEADER_HEIGHT];
        return {length, offset: (length + separator) * index + header, index};
    }

    _renderItem = (item) => {
        return (
            <View style={styles.itemView}>
                <Text style={{marginLeft: 30, fontSize: 16, color: '#333'}}>
                    {item.item.city_child}
                </Text>
                <Text style={{marginLeft: 5, fontSize: 15, color: '#999'}}>
                    {item.item.city_parent}
                </Text>
                <Text style={{marginLeft: 5, fontSize: 13, color: '#999'}}>
                    {item.item.provcn}
                </Text>
            </View>
        )
    }

    //渲染置顶的那个view A, B 这些
    _renderSectionHeader = (section) => {
        return (
            <View style={styles.headerView}>
                <Text style={styles.headerText}>{section.section.key}</Text>
            </View>
        )
    }

    __onScrollToIndexFailed = (sction) => {
        console.log("==scroll failed=")
    }
}

const styles = StyleSheet.create({

    headerView: {
        justifyContent: 'center',
        height: HEADER_HEIGHT,
        paddingLeft: 20,
        backgroundColor: '#eee'
    },
    headerText: {
        fontSize: 15,
        fontWeight: 'bold',
        color: '#3cb775'
    },
    itemView: {
        flexDirection: 'row',
        padding: 12,
        alignItems: 'center',
        height: ITEM_HEIGHT
    }
});