import React , {PureComponent, Component } from 'react'
import {SectionList, Text, View, StyleSheet, SafeAreaView, Platform,StatusBar, TextInput,Keyboard,ScrollView, TouchableOpacity} from 'react-native'
import PropTypes from 'prop-types';


// export default class DumbSectionList extends Component {

    // import React, { Component } from 'react';
    // import {
    //   TouchableOpacity
    // } from 'react-native';
    
  const sectionData = [
    {data: [{record: 'S1_Record1'}, {record: 'S1_Record2'}], key: 'Section 1'},
    {data: [{record: 'S2_Record1'}, {record: 'S2_Record2'}], key: 'Section 2'},
    {data: [{record: 'S3_Record1'}, {record: 'S3_Record2'}], key: 'Section 3'},
    {data: [{record: 'S4_Record1'}, {record: 'S4_Record2'}], key: 'Section 4'},
    {data: [{record: 'S5_Record1'}, {record: 'S5_Record2'}], key: 'Section 5'},
    {data: [{record: 'S6_Record1'}, {record: 'S6_Record2'}], key: 'Section 6'},
    {data: [{record: 'S7_Record1'}, {record: 'S7_Record2'}], key: 'Section 7'},
    {data: [{record: 'S8_Record1'}, {record: 'S8_Record2'}], key: 'Section 8'},
  ]

  export default  class example extends Component {
      constructor(props) {
        super(props)
        
        this.state = {age: 10,data:sectionData}
      }

    
      render() {
          // let sectionData = [
          //   {data: [{record: 'S1_Record1'}, {record: 'S1_Record2'}], key: 'Section 1'},
          //   {data: [{record: 'S2_Record1'}, {record: 'S2_Record2'}], key: 'Section 2'},
          //   {data: [{record: 'S3_Record1'}, {record: 'S3_Record2'}], key: 'Section 3'},
          //   {data: [{record: 'S4_Record1'}, {record: 'S4_Record2'}], key: 'Section 4'},
          //   {data: [{record: 'S5_Record1'}, {record: 'S5_Record2'}], key: 'Section 5'},
          //   {data: [{record: 'S6_Record1'}, {record: 'S6_Record2'}], key: 'Section 6'},
          //   {data: [{record: 'S7_Record1'}, {record: 'S7_Record2'}], key: 'Section 7'},
          //   {data: [{record: 'S8_Record1'}, {record: 'S8_Record2'}], key: 'Section 8'},
          // ]
         
        return (
          <View testID='container' style={styles.container}>
            <Text style={styles.h1}>Section List Test</Text>
            <SectionList
              testID='section_list'
              keyExtractor={item => item.record}
              sections={this.state.data}
              renderSectionHeader={item => <Text style={styles.h2}>{item.section.key}</Text>}
              renderItem={item => (
                <View testID={item.item.record}>
                  <TouchableOpacity
                    onPress={() => {
                      this._handleClick(item.item)
                    }}
                  >
                    <Text style={styles.record}>{item.item.record}</Text>
                        {this._createSubView(item)}
                  </TouchableOpacity>
                </View>
              )}
            />
          </View>
        )
      }

      _handleClick = (item) => {
        // item && alert(item)
        let preAge = this.state.age;
        preAge++;
        let _secData = this.state.data
        _secData.push(
          {data: [{record: `S${preAge}_Record1`}, {record: `S${preAge}_Record2`}], key: `Section ${preAge}`}
        )
        this.setState({age:preAge, data: _secData })               
      }

       _createSubView(item){
          return <View style={{flex:1,backgroundColor:'pink',justifyContent:'center',flexDirection:'row'}}>
                    <Text style={{textAlign:"center",backgroundColor:'yellow'}}
                        >Inner text {this.state.age} {item.item.record}</Text>
            </View>;
      }
    

    }
    const styles = StyleSheet.create({
        container: {
          flex: 1,
          justifyContent: 'center',
          backgroundColor: '#F5FCFF',
          padding: 20,
          paddingTop: 40
        },
        h1: {
          padding: 20,
          fontSize: 30
        },
        h2: {
          padding: 5,
          fontSize: 20,
          backgroundColor:'red'
        },
        record: {
          padding: 5
        }
      });
    
    


    // UNSAFE_componentWillMount(){

    // }

    // UNSAFE_componentWillUpdate(){

    // }

    // UNSAFE_componentWillReceiveProps(){

    // }